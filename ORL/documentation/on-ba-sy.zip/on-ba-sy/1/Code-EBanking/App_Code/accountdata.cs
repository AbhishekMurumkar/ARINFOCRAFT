using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Class1
/// </summary>
public class accountdata
{
    public string name;
    public string name1;
    public string fathers_name;
    public string dateofbirth;
    public string age;
    public string LoanType;
    public string maritalstatus;
    public string address;
    public string address1;
    public string address2;
    public string city;
    public string state;
    public string country;
    public string pincode;
    public string phone;
    public string emailid;
    public string debitcardno;
    public string branchcode;
    public string typecode;
    public string accountno;
    public string accountType;
    public string debitissuedate;
    public string debitexpdate;
    public string debitpinno;
    public string debitstatus;
    public string userid;
    public string password;
    public string UserID;
    public string Password;
    public string chequebook;
    public string toaccno;
    public string fromaccno;
    public string amount;
    public string credit;
    public string debit;
    public string TransType;
    public string balance;
    public string status;
    public string desc;
    public string Transid;
    public string oldchequebookid;
    public string RequestDate;
     
    public string TransDate;
   
 }


